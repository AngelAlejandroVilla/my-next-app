"use strict";
exports.id = 6218;
exports.ids = [6218];
exports.modules = {

/***/ 6218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ AccordionItem),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4287);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(gsap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9735);




function AccordionItem({ active , className , title , // @ts-ignore
children , number  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (0,_hooks_helper__WEBPACK_IMPORTED_MODULE_3__/* .dsnCN */ .gU)("accordion__item", className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `accordion__question ${active && "expanded"} d-flex align-items-center p-relative`,
                children: [
                    number && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "number",
                        children: number
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: "sm-title-block",
                        children: title
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `accordion__answer ${active && "active"}`,
                children: children
            })
        ]
    });
}
function Accordion({ duration =0.4 , className , children  }) {
    const accordion = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let activeIndex;
        const items = accordion.current.querySelectorAll(".accordion__item");
        if (!items) return;
        const closeAccording = ($element)=>{
            const { question , answer  } = $element.dsnAccording;
            gsap__WEBPACK_IMPORTED_MODULE_2__.gsap.set(answer, {
                height: "auto",
                display: "block",
                overflow: "hidden"
            });
            gsap__WEBPACK_IMPORTED_MODULE_2__.gsap.to(answer, {
                height: 0,
                paddingTop: 0,
                overflow: "hidden",
                display: "block",
                duration,
                clearProps: "paddingTop,height,overflow,display",
                onComplete () {
                    answer.classList.remove("active");
                    question.classList.remove("expanded");
                }
            });
        };
        const openAccording = ($element)=>{
            const { question , answer , style  } = $element.dsnAccording;
            gsap__WEBPACK_IMPORTED_MODULE_2__.gsap.set(answer, {
                height: 0,
                display: "block",
                overflow: "hidden",
                paddingTop: 0
            });
            gsap__WEBPACK_IMPORTED_MODULE_2__.gsap.to(answer, {
                height: style.height,
                duration,
                paddingTop: style.paddingTop,
                clearProps: "paddingTop,height,overflow,display",
                onComplete () {
                    answer.classList.add("active");
                    question.classList.add("expanded");
                }
            });
        };
        items.forEach(($item, $index)=>{
            const question = $item.querySelector(".accordion__question");
            const answer = $item.querySelector(".accordion__answer");
            answer.style.display = "block";
            $item.dsnAccording = {
                question,
                answer,
                style: {
                    height: answer.getBoundingClientRect().height,
                    paddingTop: window.getComputedStyle(answer).paddingTop
                }
            };
            answer.style.display = "";
            if (question?.classList.contains("expanded") && activeIndex === undefined) activeIndex = $index;
            else {
                question?.classList.remove("expanded");
                answer?.classList.remove("active");
            }
            question.addEventListener("click", function() {
                if (activeIndex === $index) return;
                if (activeIndex !== undefined) closeAccording(items[activeIndex]);
                openAccording($item);
                activeIndex = $index;
            });
        });
        return ()=>{
            items.forEach(($item)=>{
                const { dsnAccording  } = $item;
                dsnAccording.question.replaceWith(dsnAccording.question.cloneNode(true));
                delete $item.dsnAccording;
            });
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (0,_hooks_helper__WEBPACK_IMPORTED_MODULE_3__/* .dsnCN */ .gU)("dsn-accordion accordion", className),
        ref: accordion,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "accordion__wrapper",
            children: children
        })
    });
}
Accordion.item = AccordionItem;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Accordion);


/***/ })

};
;