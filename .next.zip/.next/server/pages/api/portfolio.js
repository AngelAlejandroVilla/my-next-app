"use strict";
(() => {
var exports = {};
exports.id = 6952;
exports.ids = [6952];
exports.modules = {};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5760], () => (__webpack_exec__(5760)));
module.exports = __webpack_exports__;

})();