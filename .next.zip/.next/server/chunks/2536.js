"use strict";
exports.id = 2536;
exports.ids = [2536];
exports.modules = {

/***/ 2536:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jq": () => (/* binding */ getPortfolioData),
/* harmony export */   "p8": () => (/* binding */ getPortfolioLink)
/* harmony export */ });
/* unused harmony export getPortfolioItem */
const data = [
    {
        id: 1,
        title: "NFT CONSULTING",
        slug: "maybe-speaker",
        category: [],
        description: "Compromiso Inquebrantable, Resultado Insuperables",
        src: "/img/team/15.jpg",
        overlay: 6
    },
    {
        id: 2,
        title: "Soluciones Fiscales",
        slug: "yaren-collection",
        src: "/img/team/8.jpg",
        category: [],
        description: "En NFT CONSULTING nos encargamos de tu comodidad",
        overlay: 6
    },
    {
        id: 3,
        title: "Contactanos Ahora",
        slug: "huggl-power-pack",
        src: "/img/team/1Img.jpg",
        category: [],
        description: "La Mejor Comunicacion Para Nuestros Clientes",
        overlay: 6
    }
];
const getPortfolioData = ()=>data;
const getPortfolioItem = (value, whereName = "slug")=>{
    return data.find((item)=>item[whereName] === value);
};
const getPortfolioLink = (item)=>{
    if (item) return item.slug && "/portfolio/" + item.slug;
    return "";
};


/***/ })

};
;